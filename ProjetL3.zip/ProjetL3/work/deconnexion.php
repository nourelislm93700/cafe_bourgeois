<?php
// Démarrer la session
session_start();

// Détruire toutes les variables de session
session_unset();

// Détruire la session
session_destroy();

// Rediriger vers la page d'accueil ou de connexion
header("Location: page_principale.html");  // Vous pouvez rediriger vers une autre page comme 'connexion.php'
exit();
?>
