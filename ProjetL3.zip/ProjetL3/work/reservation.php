<?php 
// Connexion à la base de données (à adapter selon vos paramètres)
$serveur = "localhost";
$utilisateur = "root";
$mot_de_passe = "190878Ab+";
$base_de_donnees = "cafe_bourgeois";

$idcon = new mysqli($serveur, $utilisateur, $mot_de_passe, $base_de_donnees);

// Vérifier la connexion
if ($idcon->connect_error) {
    die("La connexion à la base de données a échoué : " . $idcon->connect_error);
}

// Récupérer les données du formulaire
$nom_client = $_POST['nom'] ?? '';
$email = $_POST['email'] ?? '';
$telephone = $_POST['phone'] ?? '';
$date = $_POST['date'] ?? '';
$heure = $_POST['heure'] ?? '';
$nombre_personne = $_POST['guests'] ?? '';
$message = $_POST['message'] ?? '';

// Préparer la requête SQL d'insertion
$requete = $idcon->prepare("INSERT INTO reservations (nom_client, email, telephone, date_reservation, heure, nombre_personne, message) 
                            VALUES (?, ?, ?, ?, ?, ?, ?)");
// Vérifier la préparation de la requête
if (!$requete) {
    die("Erreur de préparation de la requête : " . $idcon->error);
}

// Binder les paramètres à la requête
$requete->bind_param("sssssis", $nom_client, $email, $telephone, $date, $heure, $nombre_personne, $message);

// Exécuter la requête
if ($requete->execute()) {
    // Création de la page HTML avec un div centré
    echo "
    <!DOCTYPE html>
    <html>
    <head>
        <title>Confirmation de réservation</title>
        <style>
            body {
                font-family: 'Century Gothic', Arial, Helvetica, sans-serif;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                margin: 0;
                background-image: url(paris_4.png);
                background-size: cover;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-position: center;
            }
            .confirmation-box {
                background-color: #800000; /* Couleur bordeaux */
                color: white;
                padding: 20px;
                border-radius: 25px;
                width: 90%;
                max-width: 650px;
                border: solid white 2px;
            }
            h1 {
                font-size: 24px;
                margin-bottom: 35px;
                margin-left: 155px;
                width: fit-content;
                border: solid white 2px;
                padding: 10px;
                border-radius: 15px;
            }
            h1:hover {
                scale: 1.2;
                transition: 1s ease-in-out;
            }
            p {
                font-size: 18px;
                margin-bottom: 10px;
                margin-left: 35px;
            }
            a {
                color: #ffffff;
                text-decoration: none;
                padding: 10px 20px;
                border-radius: 5px;
                margin-top: 20px;
                display: inline-block;
                margin-left: 230px;
            }
            a:hover {
                color: black;
                transition: 1s ease;
            }
        </style>
    </head>
    <body>
        <div class='confirmation-box'>
            <h1>Réservation réussie, Merci !</h1>

            <p><strong>Nom :</strong> " . htmlspecialchars($nom_client) . "</p>
            <p><strong>Email :</strong> " . htmlspecialchars($email) . "</p>
            <p><strong>Téléphone :</strong> " . htmlspecialchars($telephone) . "</p>
            <p><strong>Date de réservation :</strong> " . htmlspecialchars($date) . "</p>
            <p><strong>Heure :</strong> " . htmlspecialchars($heure) . "</p>
            <p><strong>Nombre de personnes :</strong> " . htmlspecialchars($nombre_personne) . "</p>
            <p><strong>Message :</strong> " . nl2br(htmlspecialchars($message)) . "</p>
            <b><a href='reservation.html'>Retour à l'accueil</a></b>
        </div>
    </body>
    </html>
    ";
} else {
    echo "Erreur lors de l'exécution de la requête : " . $requete->error;
}

// Fermer la requête
$requete->close();

// Fermer la connexion à la base de données

$idcon->close();
?>
