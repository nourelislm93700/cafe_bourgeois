<?php
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['client_id'])) {
    // Si la session n'est pas définie, rediriger vers la page de connexion
    header("Location: connexion.php");
    exit();
}

// Si l'utilisateur est connecté, afficher son espace personnel
echo "<h1 style='width:fit-content;border-bottom: 6px solid rgb(100,2,2);'>Bienvenue dans votre espace personnel  ! </h1>";
echo "<h4 style='width:fit-content;border-bottom: 1px solid black;' >Votre ID utilisateur est : " . $_SESSION['client_id'] . "</h4>";
echo '<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="web_icon.png">
    <link rel="stylesheet" type="text/css" href="style1.css">
    <title>Café Bourgeois</title>
    <style>
        .img3 {
            width: 100%;
            max-width: 550px;
            height: 550px;
            object-fit: cover;
            border-radius: 10px;
            transition: all 0.6s ease;
            border: 5px solid rgb(100, 2, 2);
        }
        .footer a
        {
         
        text-decoration : none;
        color : black;
}

        .pic_2 {
            display: flex;
            justify-content: space-around;
        }

        .overlay {
            position: relative;
        }

        .text {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
            font-size: 20px;
            font-weight: bold;
            text-shadow: 2px 2px 4px black;
            opacity: 0;
            transition: all 0.7s ease;
            pointer-events: none;
        }

        .gallery {
            display: flex;
            flex-direction: row;
            flex-wrap: wrap;
            justify-content: space-around;
            align-items: center;
            gap: 16px;
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px 10px;
            margin-top : 25px;
        }

        .overlay:hover .img3 {
            filter: blur(5px);
        }

        .overlay:hover .text {
            opacity: 1;
        }

.diaporama {
    position: relative;
    width: 100vw; /* Largeur de l\'écran */
    width : 100%;
    height: 80vh; /* Hauteur de l\'écran */
    overflow: hidden;
    display: flex;
    justify-content: center; /* Centrer les images horizontalement */
    align-items: center; /* Centrer les images verticalement */
}

.diaporama img {
    position: absolute;
    width: 100%;
    max-width: 1500px;
    height: 100%;
    max-height: 800px;
    object-fit: cover; /* Assurez-vous que l\'image couvre toute la zone sans déformation */
    opacity: 0; /* Les images sont invisibles par défaut */
    transition: opacity 1.5s ease-in-out;
    z-index: -1; /* Placer les images en arrière-plan */
}

.diaporama img.active {
    opacity: 1; /* L\'image active est visible */
    z-index: 1; /* Mettre l\'image active au premier plan */
} 

.movable-element {
            width: 150px;
            height: 150px;
            background-color: rgb(100, 2, 2);
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 20px;
            border-radius: 50%;
            position:relative;
            cursor: pointer;
            animation: moveLeftRight  10s infinite alternate; /* Animation gauche-droite */
            transition: filter 5s ease;
            margin-bottom:30px;
            text-decoration: none;
        }

        @keyframes moveLeftRight {
            0% {
                transform: translateX(20);
            }
            100% {
                transform: translateX(60vw); /* Déplace à droite sur toute la largeur de la fenêtre */
            }
        }

        .movable-element:hover {
            filter: blur(5px); /* Applique un flou lors du survol */
        }
        #link-res
        {
            text-decoration: none;
        }
            #deconnexion-b
            {
    width: 100%;
    padding: 12px;
    font-size: 18px;
    background-color: #fff; 
    color: #000; 
    border: none;
    border-radius: 8px; 
    cursor: pointer;
    font-weight: bold;
    transition:  0.5s ease;
          }
    #deconnexion-b:hover {
    background-color:rgb(99, 2, 2); 
    color: #fff; 
    border: 1px solid #fff; 
}
    .byby
    {
    margin-top : 15px;
    width : fit-content;
   
    }


    </style>
</head>

<body>

    

    <div class="header">
        <img alt="logo" id="logo" src="logo.PNG" width="15%" height="5%">
        <h1 id="titre">Café Bourgeois</h1>
       
    </div>

    <div class="menu">
        <menu>
            <ul class="menu_1">
                <a href="page_principale.html"><li class="item">Accueil</li></a>
                <a href="menu.html"><li class="item">Menu</li></a>
                <a href="brunch.html"><li class="item">Brunch</li></a>
                <a href="reservation.html"><li class="item">Nouvelle Réservation</li></a>
                <a href="Historique.html"><li class="item"> Historique </li></a>
                <a href="contact.html"><li class="item">Contact</li></a>
            </ul>
        </menu>
    </div>

    <div class="partie_1"></div>
    <div class="byby">
     <form action="deconnexion.php" method="post">
        <button id="deconnexion-b" type="submit">Se déconnecter</button>  <!-- Bouton de déconnexion -->
</form>
</div>
    <div class="partie_2">
        <h1 id="t_1">Le Bourgeois</h1>

        <p id="p_1">
            Découvrez Le Bourgeois, restaurant gastronomique de luxe à Paris, où une cuisine française raffinée et créative est sublimée par un chef étoilé.
            <br/> Dans un cadre élégant et intimiste, chaque détail est pensé pour une expérience unique. Offrez-vous un moment d’exception au cœur de la haute gastronomie parisienne.
        </p>
        
        <div class="partie_1"></div>


        <div class="diaporama">
            <img class="img2" alt="vin_rouge" src="vin_rouge.png">
            <img src="paris_6.png" class="img2 active" alt="Vue du restaurant">
            <img src="cafee_2.png" class="img2" alt="Plat gastronomique">

        </div>

    </div>
    <br>

<div class="partie_1"></div>

    <a id="link-res" href="client_reservation.html">
        <div class="movable-element">
            Réservez !
        </div>
        </a>

    <div class="gallery">
        <div class="pic_2">
            <div class="overlay">
                <a href="menu.html">
                    <img id="mypic1" class="img3" alt="fondant" src="fondant.png">
                    <div class="text">Testez les meilleures recettes de fondant au chocolat à Paris pour une expérience gourmande inoubliable !</div>
                </a>
            </div>
        </div>

        <div class="pic_2">
            <div class="overlay">
                <a href="menu.html">
                    <img id="mypic2" class="img3" alt="cafe" src="cafe.png">
                    <div class="text">Dénichez les cafés d’exception à Paris pour savourer une tasse inoubliable !</div>
                </a>
            </div>
        </div>

        <div class="pic_2">
            <div class="overlay">
                <a href="menu.html">
                    <img id="mypic3" class="img3" alt="pavlova" src="pavlova.png">
                    <div class="text">Goûtez les meilleures pavlovas de Paris pour une explosion de douceur et de légèreté !</div>
                </a>
            </div>
        </div>
        <div class="pic_2">
            <div class="overlay">
                <a href="menu.html">
                    <img id="mypic1" class="img3" alt="fois gras" src="gras.png">
                    <div class="text">Dégustez notre fois gras exceptionnel pour une expérience culinaire raffinée à Paris !</div>
                </a>
            </div>
        </div>
        
        <div class="pic_2">
            <div class="overlay">
                <a href="menu.html">
                    <img id="mypic2" class="img3" alt="salade" src="salade.png">
                    <div class="text">Goûtez nos salades fraîches et raffinées, idéales pour une expérience légère et savoureuse à Paris !</div>
                </a>
            </div>
        </div>
        
        <div class="pic_2">
            <div class="overlay">
                <a href="menu.html">
                    <img id="mypic3" class="img3" alt="soupe" src="soupe.png">
                    <div class="text">Savourez nos soupes maison pour une touche de chaleur et de réconfort à Paris !</div>
                </a>
            </div>
        </div>
        
        <div class="pic_2">
            <div class="overlay">
                <a href="menu.html">
                    <img id="mypic4" class="img3" alt="susiss" src="susiss.png">
                    <div class="text">Découvrez une entrée magnifique avec nos spécialités de susiss pour une explosion de saveurs à Paris !</div>
                </a>
            </div>
        </div>
        


        <div class="pic_2">
            <div class="overlay">
                <a href="menu.html">
                    <img id="mypic4" class="img3" alt="branchi" src="branchi.png">
                    <div class="text">Profitez des meilleurs brunchs du dimanche à Paris pour un moment gourmand et convivial !</div>
                </a>
            </div>
     
    </div>
</div>
<a id="link-res" href="client_reservation.html">
<div class="movable-element">
    Réservez !
</div>
</a>
    <footer>
        <div class="footer_1">
            <h3>Navigation</h3>
            <ul>
                <li><a href="page_principale.html">Accueil</a></li>
                <li><a href="menu.html">Menu</a></li>
                <li><a href="brunch.html">Brunch</a></li>
                <li><a href="client_reservation.html"> Nouvelle Réservation</a></li>
                <li><a href="historique.html"> Historique </a></li>
                <li><a href="contact.html">Contact</a></li>
            </ul>
        </div>

        <div class="footer_2">
            <h3>Informations de contact</h3>
            <a href="mailto:43005935@parisnanterre.fr">✉️ 43005935@parisnanterre.fr</a>
            <br>
            <a href="tel:+33780282744">📞 +33 7 80 28 27 44</a>
            <br>
            <a href="https://www.google.com/maps?q=Paris,+Île-de-France" target="_blank">📍 Paris, Île-de-France</a>
        </div>

        <div class="footer_3">
            <h3>Suivez-nous !</h3>
            <a href="#">Instagram</a>
            <br>
            <a href="#">Facebook</a>
            <br>
            <a href="#">Twitter</a>
            <br>
            <a href="#">LinkedIn</a>
        </div>
    </footer>

    <script>
        const images = document.querySelectorAll(\'.diaporama img\');
        let currentIndex = 0;

        function showNextImage() {
            images[currentIndex].classList.remove(\'active\');
            currentIndex = (currentIndex + 1) % images.length;
            images[currentIndex].classList.add(\'active\');
        }

        setInterval(showNextImage, 2000);
    </script>
</body>
</html>';
?>

