<?php
// Connexion à la base de données (à adapter selon vos paramètres)
$serveur = "localhost";
$utilisateur = "root";
$mot_de_passe = "190878Ab+";
$base_de_donnees = "cafe_bourgeois";

$idcon = new mysqli($serveur, $utilisateur, $mot_de_passe, $base_de_donnees);

// Vérifier la connexion
if ($idcon->connect_error) {
    die("La connexion à la base de données a échoué : " . $idcon->connect_error);
}

// Récupérer les données du formulaire
$nom_complet = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$sujet = $_POST['subject'] ?? '';
$message = $_POST['message'] ?? '';

// Préparer la requête SQL d'insertion
$requete = $idcon->prepare("INSERT INTO contacts (nom_complet, email, sujet, message) VALUES (?, ?, ?, ?)");

// Vérifier la préparation de la requête
if (!$requete) {
    die("Erreur de préparation de la requête : " . $idcon->error);
}

// Lier les paramètres à la requête
$requete->bind_param("ssss", $nom_complet, $email, $sujet, $message);

// Exécuter la requête
if ($requete->execute()) {
    // Création de la page HTML avec un div centré pour la confirmation
    echo "
    <!DOCTYPE html>
    <html lang='fr'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Confirmation de contact</title>
        <link rel='stylesheet' href='style1.css'>
        <style>
            body {
                font-family: 'Century Gothic', Arial, Helvetica, sans-serif;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                margin: 0;
                background-image: url(paris_4.png);
                background-size: cover;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-position: center;
            }
            .confirmation-box {
                background-color: #800000; /* Couleur bordeaux */
                color: white;
                padding: 20px;
                border-radius: 25px;
                width: 90%;
                max-width: 650px;
                border: solid white 2px;
            }
            h1 {
                font-size: 24px;
                margin-bottom: 20px;
                text-align: center;
                border: solid white 2px;
                padding: 10px;
                border-radius: 15px;
                display: inline-block;
            }
            p {
                font-size: 18px;
                margin: 10px 0;
            }
            a {
                color: #ffffff;
                text-decoration: none;
                padding: 10px 20px;
                border-radius: 5px;
                display: inline-block;
                margin-top: 20px;
            }
            a:hover {
                color: black;
                transition: 0.3s ease;
            }
        </style>
    </head>
    <body>
        <div class='confirmation-box'>
            <h1> Merci de nous avoir contactés ! Nous vous répondrons dans les plus brefs délais. </h1>
            <p><strong>Nom complet :</strong> " . htmlspecialchars($nom_complet) . "</p>
            <p><strong>Email :</strong> " . htmlspecialchars($email) . "</p>
            <p><strong>Sujet :</strong> " . htmlspecialchars($sujet) . "</p>
            <p><strong>Message :</strong> " . nl2br(htmlspecialchars($message)) . "</p>
            <a href='contact.html'>Retour au formulaire</a>
        </div>
    </body>
    </html>
    ";
} else {
    echo "Erreur lors de l'exécution de la requête : " . $requete->error;
}

// Fermer la requête
$requete->close();

// Fermer la connexion à la base de données
$idcon->close();
?>
