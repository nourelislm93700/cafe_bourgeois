<?php
// Connexion à la base de données
$serveur = "localhost";
$utilisateur = "root";
$mot_de_passe = "190878Ab+";
$base_de_donnees = "cafe_bourgeois";

$idcon = new mysqli($serveur, $utilisateur, $mot_de_passe, $base_de_donnees);

// Vérifier la connexion
if ($idcon->connect_error) {
    die("La connexion à la base de données a échoué : " . $idcon->connect_error);
}

// Récupérer les données du formulaire
$nom = $_POST['nom'] ?? '';
$prenom = $_POST['prenom'] ?? '';
$date_naissance = $_POST['date_naissance'] ?? '';
$email = $_POST['email'] ?? '';
$telephone = $_POST['phone'] ?? '';
$password = $_POST['password'] ?? '';

// Préparer la requête SQL d'insertion
$requete = $idcon->prepare("INSERT INTO clients (nom, prenom, date_naissance, email, telephone, mot_de_passe) 
                            VALUES (?, ?, ?, ?, ?, ?)");

// Vérifier la préparation de la requête
if (!$requete) {
    die("Erreur de préparation de la requête : " . $idcon->error);
}

// Hacher le mot de passe
$mot_de_passe_hache = password_hash($password, PASSWORD_DEFAULT);
$requete->bind_param("ssssss", $nom, $prenom, $date_naissance, $email, $telephone, $mot_de_passe_hache);

// Exécuter la requête et afficher la confirmation
if ($requete->execute()) {
    echo "
    <!DOCTYPE html>
    <html>
    <head>
        <title>Confirmation d'inscription</title>
        <style>
            body {
                font-family: 'Century Gothic', Arial, sans-serif;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                margin: 0;
                background-image: url(paris_4.png);
                background-size: cover;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-position: center;
            }
            .confirmation-box {
                background-color: #800000; /* Couleur bordeaux */
                color: white;
                padding: 20px;
                border-radius: 25px;
                width: 90%;
                max-width: 650px;
                border: solid white 2px;
            }
            h1 {
                font-size: 24px;
                margin-bottom: 35px;
                margin-left: 155px;
                width: fit-content;
                border: solid white 2px;
                padding: 10px;
                border-radius: 15px;
            }
            h1:hover {
                scale: 1.2;
                transition: 1s ease-in-out;
            }
            p {
                font-size: 18px;
                margin-bottom: 10px;
                margin-left: 35px;
            }
            a {
                color: #ffffff;
                text-decoration: none;
                padding: 10px 20px;
                border-radius: 5px;
                margin-top: 20px;
                display: inline-block;
                margin-left: 230px;
            }
            a:hover {
                color: black;
                transition: 1s ease;
            }
        </style>
    </head>
    <body>
        <div class='confirmation-box'>
            <h1>Inscription réussie, Merci !</h1>
            <p><strong>Nom :</strong> " . htmlspecialchars($nom) . "</p>
            <p><strong>Prénom :</strong> " . htmlspecialchars($prenom) . "</p>
            <p><strong>Date de naissance :</strong> " . htmlspecialchars($date_naissance) . "</p>
            <p><strong>Email :</strong> " . htmlspecialchars($email) . "</p>
            <p><strong>Téléphone :</strong> " . htmlspecialchars($telephone) . "</p>
            <b><a href='page_principale.html'>Retour à l'accueil</a></b>
        </div>
    </body>
    </html>
    ";
} else {
    echo "Erreur lors de l'exécution de la requête : " . $requete->error;
}

// Fermer la requête
$requete->close();

// Fermer la connexion à la base de données
$idcon->close();
?>
