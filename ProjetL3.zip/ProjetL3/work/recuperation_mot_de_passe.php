<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'] ?? '';

    // Validation de l'email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message_html = "Veuillez entrer une adresse e-mail valide.";
    } else {
        // Connexion à la base de données
        $conn = new mysqli('localhost', 'root', '190878Ab+', 'cafe_bourgeois');
        
        if ($conn->connect_error) {
            die("Connexion échouée : " . $conn->connect_error);
        }

        // Rechercher le client par email
        $stmt = $conn->prepare("SELECT * FROM clients WHERE email = ?");
        if ($stmt === false) {
            $message_html = "Erreur de requête. Veuillez réessayer plus tard.";
        } else {
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            // Si le client existe
            if ($result->num_rows > 0) {
                $token = bin2hex(random_bytes(50)); // Générer un token unique
                $stmt = $conn->prepare("UPDATE clients SET reset_token = ?, reset_token_expire = DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE email = ?");
                if ($stmt) {
                    $stmt->bind_param("ss", $token, $email);
                    $stmt->execute();

                    // Créer le lien de réinitialisation avec le token
                    $reset_link = "http://votre-site.com/reset_password.php?token=" . $token;

                    // Préparer l'e-mail
                    $subject = "Récupération de mot de passe";
                    $message = "Bonjour,\n\nCliquez sur le lien suivant pour réinitialiser votre mot de passe :\n" . $reset_link . "\n\nSi vous n'avez pas demandé cette réinitialisation, ignorez ce message.";
                    $headers = "From: noreply@votre-site.com";

                    if (mail($email, $subject, $message, $headers)) {
                        $message_html = "Un e-mail avec les instructions de réinitialisation a été envoyé.";
                    } else {
                        $message_html = "Erreur lors de l'envoi de l'e-mail. Veuillez vérifier votre configuration SMTP.";
                    }
                } else {
                    $message_html = "Erreur lors de la mise à jour du Programme veuillez nous contacter +33780282744 .";
                }
            } else {
                $message_html = "Aucun client trouvé avec cet e-mail.";
            }
        }

        $conn->close();
    }
} else {
    $message_html = "Veuillez soumettre l'email.";
}

// Générer le HTML
echo "
<!DOCTYPE html>
<html lang='fr'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Récupération de mot de passe</title>
    <style>
        body {
            font-family: 'Century Gothic', Arial, Helvetica, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-image: url(paris_4.png);
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-position: center;
        }

        .confirmation-box {
            background-color: #800000;
            color: white;
            padding: 20px;
            border-radius: 25px;
            width: 90%;
            max-width: 650px;
            border: solid white 2px;
        }

        h1 {
            font-size: 24px;
            margin-bottom: 20px;
            text-align: center;
            border: solid white 2px;
            padding: 10px;
            border-radius: 15px;
            display: inline-block;
        }

        p {
            font-size: 18px;
            margin: 10px 0;
        }

        a {
            color: #ffffff;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            display: inline-block;
            margin-top: 20px;
        }

        a:hover {
            color: black;
            transition: 0.3s ease;
        }
    </style>
</head>
<body>
    <div class='confirmation-box'>
        <h1>Récupération du mot de passe</h1>
        <p>" . htmlspecialchars($message_html) . "</p>
        <a href='espace_1.html'>Retour à la connexion</a>
    </div>
</body>
</html>
";
?>
