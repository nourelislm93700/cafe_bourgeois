<?php
// Démarrer une session pour garder l'utilisateur connecté
session_start();

// Configuration de la connexion à la base de données
$serveur = "localhost";
$utilisateur = "root";
$mot_de_passe = "190878Ab+";
$base_de_donnees = "cafe_bourgeois";

// Connexion à la base de données
$idcon = new mysqli($serveur, $utilisateur, $mot_de_passe, $base_de_donnees);

// Vérification de la connexion
if ($idcon->connect_error) {
    die("La connexion à la base de données a échoué : " . $idcon->connect_error);
}

// Initialisation d'une variable d'erreur
$erreur = '';

// Vérifier si le formulaire est soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer les données du formulaire
    $email = $_POST['email'];
    $mot_de_passe = $_POST['mot_de_passe'];

    // Vérifier si l'email existe dans la base de données
    $requete = $idcon->prepare("SELECT id_client, mot_de_passe FROM clients WHERE email = ?");
    $requete->bind_param("s", $email);  // 's' signifie "string"
    $requete->execute();
    $resultat = $requete->get_result();

    // Si l'email existe dans la base de données
    if ($resultat->num_rows > 0) {
        // Récupérer le client trouvé
        $client = $resultat->fetch_assoc();

        // Vérifier si le mot de passe correspond
        if (password_verify($mot_de_passe, $client['mot_de_passe'])) {
            // Mot de passe correct, connexion réussie
            $_SESSION['client_id'] = $client['id_client'];  // Stocker l'ID du client dans la session

            // Rediriger vers l'espace personnel
            header("Location: espace_personnel.php");
            exit();
        } else {
            // Mot de passe incorrect
            $erreur = "Mot de passe incorrect.";
        }
    } else {
        // Aucun utilisateur trouvé avec cet email
        $erreur = "Aucun compte trouvé avec cet email.";
    }

    // Fermer la requête préparée
    $requete->close();
}

// Fermer la connexion à la base de données
$idcon->close();
?>
