-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : ven. 17 jan. 2025 à 13:38
-- Version du serveur : 8.3.0
-- Version de PHP : 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `cafe_bourgeois`
--

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

DROP TABLE IF EXISTS `clients`;
CREATE TABLE IF NOT EXISTS `clients` (
  `id_client` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telephone` varchar(15) NOT NULL,
  `date_naissance` date NOT NULL,
  `mot_de_passe` varchar(255) NOT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_client`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `clients`
--

INSERT INTO `clients` (`id_client`, `nom`, `prenom`, `email`, `telephone`, `date_naissance`, `mot_de_passe`, `reset_token`) VALUES
(8, 'Nour el islam', '', 'nourelislam1.cm@gmail.com', '0780282744', '2003-05-25', '$2y$10$dFaUhSvaelE6A0CSu52hkuFkctDHAnqOarOfJDtL50NWtEGvHtKXu', '3d07daf6b89dbd911923bb2cc4d3f00994c4324e09bfc134a63647a004b19fafd628debd9f71390bc5790252d3f65e73611f');

-- --------------------------------------------------------

--
-- Structure de la table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
CREATE TABLE IF NOT EXISTS `contacts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom_complet` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `sujet` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `date_creation` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `reservations`
--

DROP TABLE IF EXISTS `reservations`;
CREATE TABLE IF NOT EXISTS `reservations` (
  `id_reservation` int NOT NULL AUTO_INCREMENT,
  `nom_client` varchar(50) NOT NULL,
  `telephone` varchar(15) NOT NULL,
  `date_reservation` date NOT NULL,
  `heure` time NOT NULL,
  `nombre_personne` int NOT NULL,
  `message` varchar(600) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_reservation`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `reservations`
--

INSERT INTO `reservations` (`id_reservation`, `nom_client`, `telephone`, `date_reservation`, `heure`, `nombre_personne`, `message`, `email`) VALUES
(7, 'Alice Le blanc', '0525785201', '2025-01-17', '13:30:00', 2, '', 'aliceleblanc75002@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `tables_restaurant`
--

DROP TABLE IF EXISTS `tables_restaurant`;
CREATE TABLE IF NOT EXISTS `tables_restaurant` (
  `id_table` int NOT NULL AUTO_INCREMENT,
  `numero_table` int NOT NULL,
  `capacite` int NOT NULL,
  `localisation` varchar(50) NOT NULL,
  PRIMARY KEY (`id_table`),
  UNIQUE KEY `numero_table` (`numero_table`)
) ENGINE=InnoDB AUTO_INCREMENT=197 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `tables_restaurant`
--

INSERT INTO `tables_restaurant` (`id_table`, `numero_table`, `capacite`, `localisation`) VALUES
(1, 1, 2, 'Le Face Bar'),
(2, 2, 2, 'Le Face Bar'),
(3, 3, 3, 'Le Face Bar'),
(4, 4, 4, 'Le Face Bar'),
(5, 5, 2, 'Le Face Bar'),
(6, 6, 2, 'Le Face Bar'),
(7, 7, 3, 'Le Face Bar'),
(8, 8, 4, 'Le Face Bar'),
(9, 9, 2, 'Le Face Bar'),
(10, 10, 2, 'Le Face Bar'),
(11, 11, 2, 'Le Face Bar'),
(12, 12, 3, 'Le Face Bar'),
(13, 13, 4, 'Le Face Bar'),
(14, 14, 2, 'Le Face Bar'),
(15, 15, 2, 'Le Face Bar'),
(16, 16, 3, 'Le Face Bar'),
(17, 17, 4, 'Le Face Bar'),
(18, 18, 2, 'Le Face Bar'),
(19, 19, 2, 'Le Face Bar'),
(20, 20, 2, 'Le Face Bar'),
(21, 21, 3, 'Le Face Bar'),
(22, 22, 4, 'Le Face Bar'),
(23, 30, 2, 'Salle Principale'),
(24, 31, 2, 'Salle Principale'),
(25, 32, 3, 'Salle Principale'),
(26, 33, 4, 'Salle Principale'),
(27, 34, 2, 'Salle Principale'),
(28, 35, 2, 'Salle Principale'),
(29, 36, 3, 'Salle Principale'),
(30, 37, 4, 'Salle Principale'),
(31, 38, 2, 'Salle Principale'),
(32, 39, 2, 'Salle Principale'),
(33, 40, 2, 'Salle Principale'),
(34, 41, 3, 'Salle Principale'),
(35, 42, 4, 'Salle Principale'),
(36, 43, 2, 'Salle Principale'),
(37, 44, 2, 'Salle Principale'),
(38, 45, 3, 'Salle Principale'),
(39, 46, 4, 'Salle Principale'),
(40, 47, 2, 'Salle Principale'),
(41, 48, 2, 'Salle Principale'),
(42, 49, 2, 'Salle Principale'),
(43, 50, 3, 'Salle Principale'),
(44, 51, 4, 'Salle Principale'),
(45, 52, 2, 'Salle Principale'),
(46, 53, 2, 'Salle Principale'),
(47, 54, 3, 'Salle Principale'),
(48, 55, 4, 'Salle Principale'),
(49, 56, 2, 'Salle Principale'),
(50, 57, 2, 'Salle Principale'),
(51, 58, 3, 'Salle Principale'),
(52, 59, 4, 'Salle Principale'),
(53, 60, 2, 'Salle Principale'),
(54, 61, 2, 'Salle Principale'),
(55, 62, 2, 'Salle Principale'),
(56, 63, 3, 'Salle Principale'),
(57, 64, 4, 'Salle Principale'),
(58, 65, 2, 'Salle Principale'),
(59, 66, 2, 'Salle Principale'),
(60, 67, 3, 'Salle Principale'),
(61, 68, 4, 'Salle Principale'),
(62, 69, 2, 'Salle Principale'),
(63, 100, 2, 'L\'Étage'),
(64, 101, 2, 'L\'Étage'),
(65, 102, 3, 'L\'Étage'),
(66, 103, 4, 'L\'Étage'),
(67, 104, 2, 'L\'Étage'),
(68, 105, 2, 'L\'Étage'),
(69, 106, 3, 'L\'Étage'),
(70, 107, 4, 'L\'Étage'),
(71, 108, 2, 'L\'Étage'),
(72, 109, 2, 'L\'Étage'),
(73, 110, 2, 'L\'Étage'),
(74, 111, 3, 'L\'Étage'),
(75, 112, 4, 'L\'Étage'),
(76, 113, 2, 'L\'Étage'),
(77, 114, 2, 'L\'Étage'),
(78, 115, 3, 'L\'Étage'),
(79, 116, 4, 'L\'Étage'),
(80, 117, 2, 'L\'Étage'),
(81, 118, 2, 'L\'Étage'),
(82, 119, 2, 'L\'Étage'),
(83, 120, 3, 'L\'Étage'),
(84, 121, 4, 'L\'Étage'),
(85, 122, 2, 'L\'Étage'),
(86, 123, 2, 'L\'Étage'),
(87, 124, 3, 'L\'Étage'),
(88, 125, 4, 'L\'Étage'),
(89, 126, 2, 'L\'Étage'),
(90, 127, 2, 'L\'Étage'),
(91, 128, 3, 'L\'Étage'),
(92, 129, 4, 'L\'Étage'),
(93, 130, 2, 'L\'Étage'),
(94, 131, 2, 'L\'Étage'),
(95, 132, 2, 'L\'Étage'),
(96, 133, 3, 'L\'Étage'),
(97, 134, 4, 'L\'Étage'),
(98, 135, 2, 'L\'Étage'),
(99, 136, 2, 'L\'Étage'),
(100, 137, 3, 'L\'Étage'),
(101, 138, 4, 'L\'Étage'),
(102, 139, 2, 'L\'Étage'),
(103, 140, 2, 'L\'Étage'),
(104, 200, 2, 'Terrasse T2'),
(105, 201, 2, 'Terrasse T2'),
(106, 202, 3, 'Terrasse T2'),
(107, 203, 4, 'Terrasse T2'),
(108, 204, 2, 'Terrasse T2'),
(109, 205, 2, 'Terrasse T2'),
(110, 206, 3, 'Terrasse T2'),
(111, 207, 4, 'Terrasse T2'),
(112, 208, 2, 'Terrasse T2'),
(113, 209, 2, 'Terrasse T2'),
(114, 210, 2, 'Terrasse T2'),
(115, 211, 3, 'Terrasse T2'),
(116, 212, 4, 'Terrasse T2'),
(117, 213, 2, 'Terrasse T2'),
(118, 214, 2, 'Terrasse T2'),
(119, 215, 3, 'Terrasse T2'),
(120, 216, 4, 'Terrasse T2'),
(121, 217, 2, 'Terrasse T2'),
(122, 218, 2, 'Terrasse T2'),
(123, 219, 2, 'Terrasse T2'),
(124, 220, 3, 'Terrasse T2'),
(125, 221, 4, 'Terrasse T2'),
(126, 222, 2, 'Terrasse T2'),
(127, 223, 2, 'Terrasse T2'),
(128, 224, 3, 'Terrasse T2'),
(129, 225, 4, 'Terrasse T2'),
(130, 226, 2, 'Terrasse T2'),
(131, 227, 2, 'Terrasse T2'),
(132, 228, 3, 'Terrasse T2'),
(133, 229, 4, 'Terrasse T2'),
(134, 230, 2, 'Terrasse T2'),
(135, 231, 2, 'Terrasse T2'),
(136, 232, 2, 'Terrasse T2'),
(137, 233, 3, 'Terrasse T2'),
(138, 234, 4, 'Terrasse T2'),
(139, 235, 2, 'Terrasse T2'),
(140, 236, 2, 'Terrasse T2'),
(141, 237, 3, 'Terrasse T2'),
(142, 238, 4, 'Terrasse T2'),
(143, 239, 2, 'Terrasse T2'),
(144, 240, 2, 'Terrasse T2'),
(145, 300, 2, 'Terrasse T3'),
(146, 301, 2, 'Terrasse T3'),
(147, 302, 3, 'Terrasse T3'),
(148, 303, 4, 'Terrasse T3'),
(149, 304, 2, 'Terrasse T3'),
(150, 305, 2, 'Terrasse T3'),
(151, 306, 3, 'Terrasse T3'),
(152, 307, 4, 'Terrasse T3'),
(153, 308, 2, 'Terrasse T3'),
(154, 309, 2, 'Terrasse T3'),
(155, 310, 2, 'Terrasse T3'),
(156, 311, 3, 'Terrasse T3'),
(157, 312, 4, 'Terrasse T3'),
(158, 313, 2, 'Terrasse T3'),
(159, 314, 2, 'Terrasse T3'),
(160, 315, 3, 'Terrasse T3'),
(161, 316, 4, 'Terrasse T3'),
(162, 317, 2, 'Terrasse T3'),
(163, 318, 2, 'Terrasse T3'),
(164, 319, 2, 'Terrasse T3'),
(165, 320, 3, 'Terrasse T3'),
(166, 321, 4, 'Terrasse T3'),
(167, 322, 2, 'Terrasse T3'),
(168, 323, 2, 'Terrasse T3'),
(169, 324, 3, 'Terrasse T3'),
(170, 325, 4, 'Terrasse T3'),
(171, 326, 2, 'Terrasse T3'),
(172, 327, 2, 'Terrasse T3'),
(173, 328, 3, 'Terrasse T3'),
(174, 329, 4, 'Terrasse T3'),
(175, 330, 2, 'Terrasse T3'),
(176, 331, 2, 'Terrasse T3'),
(177, 332, 2, 'Terrasse T3'),
(178, 333, 3, 'Terrasse T3'),
(179, 334, 4, 'Terrasse T3'),
(180, 335, 2, 'Terrasse T3'),
(181, 336, 2, 'Terrasse T3'),
(182, 337, 3, 'Terrasse T3'),
(183, 338, 4, 'Terrasse T3'),
(184, 339, 2, 'Terrasse T3'),
(185, 340, 2, 'Terrasse T3'),
(186, 400, 2, 'Terrasse T4'),
(187, 401, 2, 'Terrasse T4'),
(188, 402, 3, 'Terrasse T4'),
(189, 403, 4, 'Terrasse T4'),
(190, 404, 2, 'Terrasse T4'),
(191, 405, 2, 'Terrasse T4'),
(192, 406, 3, 'Terrasse T4'),
(193, 407, 4, 'Terrasse T4'),
(194, 408, 2, 'Terrasse T4'),
(195, 409, 2, 'Terrasse T4'),
(196, 410, 2, 'Terrasse T4');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
